CREATE PROCEDURE zad1_r 
AS
BEGIN
	DECLARE @zmienna1 INT;
	SELECT @zmienna1 = COUNT(*) from emp;
	PRINT 'W tabeli jest ' + cast(@zmienna1 as VARCHAR);
END
go

