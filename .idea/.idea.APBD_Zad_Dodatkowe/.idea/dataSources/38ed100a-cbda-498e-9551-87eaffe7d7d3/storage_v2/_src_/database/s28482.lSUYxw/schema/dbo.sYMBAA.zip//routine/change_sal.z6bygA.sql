CREATE PROCEDURE change_sal
@empno INT,
@newSal INT OUTPUT,
@percent INT = 20
AS 
BEGIN
			SELECT @newSal = Sal + Sal*@percent/100
			FROM EMP
			WHERE empno = @empno;
			UPDATE emp set sal = @newSal
			WHERE empno = @empno


END
go

