CREATE PROCEDURE ProgramZad4
@nr_dzialu int,
@nazwa varchar(50),
@lokalizacja varchar(25)
AS 
BEGIN	
	IF NOT EXISTS(
				SELECT 1 FROM dept 
				WHERE DNAME = @nazwa or loc = @lokalizacja)
	BEGIN 
		INSERT INTO DEPT(DEPTNO,DNAME,LOC)
		VALUES(@nr_dzialu,@nazwa,@lokalizacja);
		PRINT 'Dodano department: ' + @nazwa;
	END
	ELSE
	BEGIN
		PRINT 'DEPARTMENT WITH THE SAME NAME OR LOCATION ALREADY EXISTS.';
	END
END
go

