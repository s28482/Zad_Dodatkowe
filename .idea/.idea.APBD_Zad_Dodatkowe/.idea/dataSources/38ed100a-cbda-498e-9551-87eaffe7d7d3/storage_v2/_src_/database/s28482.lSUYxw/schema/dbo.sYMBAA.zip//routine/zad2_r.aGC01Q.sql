CREATE PROCEDURE zad2_r
AS
BEGIN
		DECLARE @zmienna1 INT;
		SELECT @zmienna1 = COUNT(*) from emp;
		IF(@zmienna1 < 16)
			begin
				INSERT INTO emp(empno,ename,job,mgr,hiredate,sal,comm,deptno)
				VALUES(5,'kowalsk',null,null,'1987-01-01',0,0,20);
			end
		else
			begin
			PRINT'NIE WSTAWIONO';
			end
END
go

