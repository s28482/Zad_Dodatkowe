CREATE PROCEDURE dep_job
@job VARCHAR(20) = 'MANAGER',
@deptno INT =10
AS
BEGIN
	SELECT ename,job,deptno
	FROM EMP WHERE job = @job and deptno = @deptno;

END
go

