CREATE PROCEDURE proZad2
@wartosc1 INT,
@wartosc2 INT
AS
BEGIN
			DECLARE kzad1 CURSOR FOR SELECT empno,ename,sal FROM emp
	DECLARE @nrPracownika INT, @imie VARCHAR(30), @wyplata INT
	OPEN kzad1
	FETCH NEXT FROM kzad1 INTO @nrPracownika,@imie,@wyplata
	WHILE @@FETCH_STATUS = 0
	BEGIN
		IF(@wyplata < @wartosc1)
			BEGIN
			UPDATE EMP SET sal = sal*1.1 WHERE empno = @nrPracownika

			PRINT 'nr: '+ cast(@nrPracownika AS VARCHAR) +' zarabia teraz' + cast(@WYPLATA *1.1 AS VARCHAR)
			END
		ELSE IF (@wyplata > @wartosc2)
			BEGIN
			UPDATE EMP SET sal = sal*0.9 WHERE empno = @nrPracownika
			PRINT 'nr: '+ cast(@nrPracownika AS VARCHAR) +' zarabia teraz' + cast(@WYPLATA *0.9 AS VARCHAR)
			END

		FETCH NEXT FROM kzad1 INTO @nrPracownika,@imie,@wyplata
	END
	CLOSE kzad1
	DEALLOCATE kzad1
END
go

