CREATE TRIGGER tZad6 ON EMP FOR DELETE,UPDATE,INSERT
AS
BEGIN	
			DECLARE @iloscWierwszywDeleted INT;
			DECLARE @iloscWierwszywInserted INT;
			SELECT @iloscWierwszywDeleted = count(*) from DELETED;
			SELECT @iloscWierwszywINSERTED = count(*) from INSERTED;
		-- Nie pozwoli usunąć pracownika, którego pensja jest większa od 0.
		print 'deleted ' + CAST(@iloscWierwszywDeleted as VARCHAR)
		print 'INSERTED ' + CAST(@iloscWierwszywINSERTED as VARCHAR)
		if(@iloscWierwszywDeleted = 1 and @iloscWierwszywINSERTED = 0)
			begin
			print 'deleted'
			end
		

		-- Nie pozwoli zmienić nazwiska pracownika. 
		if(@iloscWierwszywDeleted = 1 and @iloscWierwszywINSERTED = 1)
		BEGIN
		print 'UPDATED'
		END

		--

		if(@iloscWierwszywDeleted = 0 and @iloscWierwszywINSERTED = 1)
		BEGIN
		print 'INSERTED'
		END

END
go

