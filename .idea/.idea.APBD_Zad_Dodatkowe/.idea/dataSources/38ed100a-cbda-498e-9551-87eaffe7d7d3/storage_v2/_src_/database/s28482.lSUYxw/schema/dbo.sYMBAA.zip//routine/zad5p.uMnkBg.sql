CREATE PROCEDURE zad5p
@parametr INT
AS
BEGIN
	DECLARE @najwiekszaIlosc INT;
SELECT @najwiekszaIlosc =  MAX(ilosc) FROM magaz;
DECLARE @idGDZIEjestNAJWIEKSZAILOSC int;
SELECT @idGDZIEjestNAJWIEKSZAILOSC = idPozycji FROM magaz WHERE Ilosc = @najwiekszaIlosc
PRINT 'NAJWIEKSZA ILOSC : ' + CAST (@najwiekszailosc AS VARCHAR)
	IF(@najwiekszaIlosc > @parametr)
		BEGIN
			UPDATE magaz SET ilosc = ilosc-@parametr WHERE IdPozycji = @idGDZIEjestNAJWIEKSZAILOSC
		END
	ELSE
	BEGIN	RAISERROR('BŁAD',10,2)													
	END


END
go

