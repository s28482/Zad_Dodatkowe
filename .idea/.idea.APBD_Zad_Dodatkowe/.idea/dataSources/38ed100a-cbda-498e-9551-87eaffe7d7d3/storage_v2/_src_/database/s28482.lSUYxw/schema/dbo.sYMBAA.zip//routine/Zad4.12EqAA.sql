CREATE PROCEDURE Zad4
@v_nrDzialu INTEGER,
@v_nazwa VARCHAR(30),
@v_loc VARCHAR(30)
AS
BEGIN
	DECLARE @liczbaIstnierjacychdzialow INTEGER;
	SELECT @liczbaIstnierjacychdzialow = count(*) from dept where dname = @v_nazwa or loc = @v_loc;

	if(@liczbaIstnierjacychdzialow > 0)
		begin 
			PRINT'DZIAL JZU ISTENIEJE'
		end
	ELSE
		BEGIN
		INSERT INTO DEPT(deptno,dname,loc)
		VALUES(@v_nrDzialu,@v_nazwa,@v_loc)
		END
END
go

