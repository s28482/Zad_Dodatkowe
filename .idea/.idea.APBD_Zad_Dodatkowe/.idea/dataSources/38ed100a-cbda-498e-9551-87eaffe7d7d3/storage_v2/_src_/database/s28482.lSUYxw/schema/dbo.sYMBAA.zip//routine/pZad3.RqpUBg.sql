CREATE PROCEDURE pZad3
@wyplata_zm INT
AS
BEGIN
	SELECT * 
	FROM EMP
	WHERE SAL > @wyplata_zm

END
go

