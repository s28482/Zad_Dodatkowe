CREATE PROCEDURE ABC @deptno INT = 10
AS
BEGIN
	DECLARE @x TABLE (nrprac INT, Nazwisko VARCHAR(20));
	INSERT INTO @x (nrprac,Nazwisko)
	SELECT empno,ename
	FROM emp
	WHERE deptno = @deptno;

	SELECT *  FROM @x;
END
go

