CREATE PROCEDURE wprowadzanie
@nazwisko_zm VARCHAR(100),
@nrdzialu_zm INT
AS
BEGIN
		DECLARE @iloscDzialowoNumerze INT;
		SET @iloscDzialowoNumerze = (SELECT COUNT(*) FROM DEPT WHERE deptno = @nrdzialu_zm);
		IF(@iloscDzialowoNumerze > 0)
			BEGIN
				DECLARE @wyliczPensja INT;
				SET @wyliczPensja = (SELECT MIN(SAL) FROM EMP WHERE DEPTNO = @nrdzialu_zm);
				DECLARE @nowyEmpno INT;
				SET @nowyEmpno = (SELECT MAX(EMPNO) FROM EMP) +1;
				INSERT INTO EMP(empno,ename,job,mgr,hiredate,sal,comm,deptno)
				VALUES(@nowyEmpno,@nazwisko_zm,null,null,'2023-10-10',@wyliczPensja,0,@nrdzialu_zm)
			END
		ELSE
			BEGIN
				RAISERROR ('Podany dział nie istneieje',16,1);
			END
END
go

