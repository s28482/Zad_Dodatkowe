create PROCEDURE proced1 
@mniejsza INT, @wieksza INT
AS
BEGIN
DECLARE kursorZad1 CURSOR FOR SELECT empno,ename, sal FROM EMP;
DECLARE @empno INT,@ename VARCHAR(50),@sal INT;
OPEN kursorZad1;
FETCH NEXT FROM kursorZad1 INTO @empno,@ename,@sal;
WHILE @@FETCH_STATUS =0
	BEGIN
		IF(@sal < @mniejsza) 
			BEGIN
				UPDATE EMP
				SET sal = sal *1.1 WHERE ename = @ename;
				PRINT 'Pracownik ' + @ename + ' zarabia teraz ' + cast(@sal as varchar);
			END
		else if(@sal >@wieksza)
			BEGIN
			UPDATE EMP
				SET sal = sal *0.9 WHERE ename = @ename;
				PRINT 'Pracownik ' + @ename + ' zarabia teraz ' + cast(@sal as varchar);
			END
FETCH NEXT FROM kursorZad1 INTO @empno,@ename,@sal;	
END

CLOSE kursorZad1;
DEALLOCATE kursorZad1;
PRINT @@FETCH_STATUS;
END
go

