CREATE PROCEDURE ProgramZad2
AS
BEGIN
	DECLARE @ZMIENNA INT = (SELECT COUNT(*) FROM EMP);
		IF(@ZMIENNA < 16)
		BEGIN
			INSERT INTO EMP (empno, ename, job, mgr, hiredate, sal, comm, deptno)
			VALUES (011, 'Kowalski', 'null', NULL, '1981-11-17', 5000, NULL, 10);
			
			Print 'Wstawiono kowalskiego'
		end	
		ELSE
		BEGIN
		PRINT 'Nie wstawiono';
		END
END
go

