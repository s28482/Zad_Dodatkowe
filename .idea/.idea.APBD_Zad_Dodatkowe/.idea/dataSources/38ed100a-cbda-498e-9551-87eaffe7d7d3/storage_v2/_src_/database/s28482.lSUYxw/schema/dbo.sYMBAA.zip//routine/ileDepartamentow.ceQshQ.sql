CREATE PROCEDURE ileDepartamentow
AS 
BEGIN
	SET NOCOUNT ON
	DECLARE @ile INT;
	SELECT @ile = count(1) from dept;
	RETURN @ile;
END
go

