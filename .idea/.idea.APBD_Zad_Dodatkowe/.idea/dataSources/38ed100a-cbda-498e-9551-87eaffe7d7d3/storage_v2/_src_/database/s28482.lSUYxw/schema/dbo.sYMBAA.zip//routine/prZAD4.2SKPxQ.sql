CREATE PROCEDURE prZAD4
AS
BEGIN
DECLARE @maxilosc int;
SELECT @maxilosc = MAX(Ilosc) FROM MAGAZYN;

		DECLARE kursorzad4 CURSOR FOR SELECT IdPozycji,Ilosc from magazyn;
		DECLARE @IdPozycji INT,
		@ilosc INT
		
		OPEN kursorzad4
		FETCH NEXT FROM kursorzad4 INTO @IdPozycji,@ilosc;
		WHILE @@FETCH_STATUS = 0
			BEGIN
					IF(@ilosc >= 5 and @ilosc = @maxilosc)
						BEGIN
							UPDATE MAGAZYN
							SET ilosc = ilosc -5
							WHERE IdPozycji = @IdPozycji;
						END
					ELSE
						BEGIN
							DECLARE @idstring VARCHAR(40);
							SELECT @idstring = CAST(@IdPozycji as VARCHAR);
							RAISERROR('DLA %s STAN JEST MNIEJSZY NIZ 5',16,1, @idstring);
						END

			FETCH NEXT FROM kursorzad4 INTO @IdPozycji,@ilosc;
			END
	CLOSE kursorzad4
    DEALLOCATE kursorzad4;
END
go

