CREATE PROCEDURE proczad3
@nrDep INT
AS
BEGIN
		

		DECLARE @avgSal DECIMAL(10,2);
		SELECT @avgSal = avg(sal) from emp where deptno = @nrDep;
		PRINT 'avg sal: ' + cast(@avgSal as varchar);
		DECLARE curszad3 CURSOR FOR SELECT empno,ename, sal FROM emp where deptno = @nrDep
		DECLARE @nrPr INT,@ename_zm VARCHAR(30),@sal_zm INT
		OPEN curszad3	
		FETCH NEXT FROM curszad3 INTO @nrPr,@ename_zm,@sal_zm
			WHILE @@FETCH_STATUS = 0
				BEGIN
					IF(@sal_zm <@avgSal)
						BEGIN 
							PRINT'WYPLATA WYNOSI' + CAST(@sal_zm AS VARCHAR)
							UPDATE EMP SET comm = ISNULL(comm,0) + (sal *0.05) WHERE empno = @nrPr
							PRINT'ZWIEKSZYLISMY DLA ' +cast(@nrPr as varchar) +'wyplate'
							
						END
					FETCH NEXT FROM curszad3 INTO @nrPr,@ename_zm,@sal_zm
				END
				CLOSE curszad3
				DEALLOCATE curszad3
			
END
go

