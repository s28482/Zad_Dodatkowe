CREATE PROCEDURE ProgramZad3
	@parametr int
	AS
	BEGIN
		SELECT * FROM EMP 
		WHERE SAL > @parametr;
	END
go

