CREATE PROCEDURE ProgramZad1
AS
BEGIN
	DECLARE @ZMIENNA INT = (SELECT COUNT(*) FROM EMP);
END;
PRINT 'W tabeli jest ' + cast(@zmienna as varchar) + ' osób.'
go

