CREATE PROCEDURE sredniaZ
@deptno INT
AS
BEGIN
	DECLARE @srednia DECIMAL (3,2);
   SELECT @srednia = AVG(SAL) FROM EMP WHERE DEPTNO = @deptno;

  UPDATE EMP
  SET SAL = SAL *1.05
  WHERE DEPTNO = @deptno
  AND SAL < @srednia;

END;
go

