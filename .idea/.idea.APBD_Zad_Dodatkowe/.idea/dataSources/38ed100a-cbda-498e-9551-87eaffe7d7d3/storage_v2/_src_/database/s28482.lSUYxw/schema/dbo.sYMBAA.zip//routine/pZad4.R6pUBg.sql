CREATE PROCEDURE pZad4
@nr_d INT,
@naz_d VARCHAR (100),
@loc_d VARCHAR(100)
AS
BEGIN
	DECLARE @liczbaIniejacych INT;
	SET @liczbaIniejacych = (SELECT COUNT(*) FROM DEPT WHERE dname =@naz_d or loc = @loc_d);

	IF(@liczbaIniejacych > 0)
		BEGIN
				PRINT 'dzial juz istnieje'
		END
	ELSE
		INSERT INTO DEPT(deptno,dname,loc)
		VALUES(@nr_d,@naz_d,@loc_d)

END
go

