CREATE TRIGGER tZad5 ON DEPT FOR UPDATE, INSERT
AS
BEGIN
		DECLARE @iloscWierszywDeleted int;
		SELECT @iloscWierszywDeleted = count(1) FROM DELETED;
		DECLARE @nazwaDeptZdeleted VARCHAR(30);
		DECLARE @nazwaDeptZINSERTED VARCHAR(30);
		IF(@iloscWierszywDeleted = 1)
		BEGIN
			SELECT @nazwaDeptZdeleted = dname from DELETED;
			SELECT @nazwaDeptZINSERTED = dname from inserted;
			IF(@nazwaDeptZdeleted != @nazwaDeptZINSERTED)
				BEGIN RAISERROR('NIE MOZNA MODYFIKOWAC NAZWY DEPT',10,2); ROLLBACK; END
		END
		
END
go

