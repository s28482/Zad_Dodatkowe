CREATE PROCEDURE wstawIf
@pNazwi VARCHAR(100) = 'Kowalski'
AS	
	BEGIN
			DECLARE @liczbaPracownikow_zm INT;
			SELECT @liczbaPracownikow_zm = count(*) from emp;
			PRINT 'Liczba pracownikow: ' + CAST(@liczbaPracownikow_zm AS VARCHAR);

			IF(@liczbaPracownikow_zm < 25)
				BEGIN
					DECLARE @newEmpno INT;
						SET  @newEmpno = (SELECT MAX(empno) FROM emp) +1;
					INSERT INTO EMP(empno,ename,job,mgr,hiredate,sal,comm,deptno)
					VALUES (@newEmpno,@pNazwi,null,null,'1981-11-11',4000,null,10);

					PRINT 'Wstawiono pracownika ' + @pNazwi;
				END
			ELSE
			BEGIN
					PRINT 'NIC NIE WSTWIONO';
			END
	END
go

